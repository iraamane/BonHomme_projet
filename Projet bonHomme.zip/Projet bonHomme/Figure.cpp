#include "Fenetres.h"
#include "Figure.h"
#include<graphics.h>
#include <iostream>
using namespace std;
Fenetres f;

void Figure::set_droite(int x, int y, int couleur, int longueur, int hauteur){
	if(longueur<0)
	longueur=-longueur;
	if(hauteur<0)
	hauteur=-hauteur;
	
	this->x=x;
	this->y=y;
	this->couleur=couleur;
	
	if(this->type==1){
	this->longueur=longueur;
	this->hauteur=0;
		
	}
	if(this->type==2){
	this->longueur=0;
	this->hauteur=hauteur;
	}
	
	if(this->type==3){
	this->longueur=longueur;
	this->hauteur=hauteur;
	}
	
	
	
}

void Figure::set_cercle(int x, int y, int couleur, int diametre){
	this->x=x;
	this->y=y;
	this->longueur=diametre/2;
	this->hauteur=diametre/2;
	this->couleur=couleur;
}

void Figure::set_croix(int x, int y, int couleur, int longueur, int hauteur){
		if(longueur<0)
	longueur=-longueur;
	if(hauteur<0)
	hauteur=-hauteur;
	
	this->x=x;
	this->y=y;
	this->longueur=longueur;
	this->hauteur=hauteur;
	this->couleur=couleur;
	
	
	
	
}

void Figure::set_rectangle(int x, int y, int couleur, int longueur, int hauteur){
		if(longueur<0)
	longueur=-longueur;
	if(hauteur<0)
	hauteur=-hauteur;
	
		
	this->x=x;
	this->y=y;
	this->longueur=longueur;
	this->hauteur=hauteur;
	this->couleur=couleur;
}

void Figure::set_triangle(int x, int y, int couleur, int longueur , int hauteur){
		if(longueur<0)
	longueur=-longueur;
	if(hauteur<0)
	hauteur=-hauteur;
	
		
	this->x=x;
	this->y=y;
	this->longueur=longueur;
	this->hauteur=hauteur;
	this->couleur=couleur;
}




	int Figure::get_couleur(){
		return this->couleur;
		
	}
	int Figure::get_x_centre(){
		return x;
	}
	
	
	int Figure::get_y_centre(){
		return y;
	}
	
	int Figure::get_x_max(){
		return x+longueur/2;
		
	}
	int Figure::get_y_max(){
		return y+hauteur/2;
		
	}
  int Figure::get_x_min(){
  	return x-longueur/2;
  }
  int Figure::get_y_min(){
  	return y-hauteur/2;
  }


void Figure::set_type(int i){
	if(i<1||i>7)
	i=1;
	this->type=i;
}

void Figure::dessiner(){	
	setcolor(couleur);
	switch(type){
		case 1:
		case 2:
		case 3:
			moveto(x,y);
		linerel(longueur,hauteur);
		break;
		case 4:
		circle(x,y,longueur);
			break;
		case 5:
		rectangle(x-(longueur/2),y-(hauteur/2),x+(longueur/2),y+(hauteur/2));
			break;
		case 6:
		line(x-(longueur/2),y-(hauteur/2),x+(longueur/2),y+(hauteur/2));
			line(x+(longueur/2),y-(hauteur/2),x-(longueur/2),y+(hauteur/2));
		break;
		case 7:
		int xtop,xdroite,xgauche;
		int ytop,ydroite,ygauche;
		xtop=x;
		ytop=y-(hauteur/2);	
		xdroite=x+(longueur/2);
		ydroite=y+(hauteur/2);
		xgauche=x-(longueur/2);
		ygauche=y+(hauteur/2);	
		line(xtop,ytop,xdroite,ydroite);
		line(xdroite,ydroite,xgauche,ygauche);
		line(xgauche,ygauche,xtop,ytop);
			
	}
		
}
	
	
	
	
void Figure::deplacer(int x, int y){
	int c=this->couleur;
	this->couleur=getbkcolor();
	dessiner();
	this->couleur=c;
	this->x=x;
	this->y=y;
	dessiner();
}
	
	

	

	
































