#include "Figure.h"
#include<graphics.h>
#include "Dessin.h"
#include <iostream>
#include "Figure.h"
#include <math.h>

using namespace std;
void Dessin::set_dessin(int x,int y,int r,int hauteur,int hauteurarm,int longueurarm,int leg){


	
	circle(x,y,r);
	rectangle(x-r,y+r,x+r,y+r+hauteur);
    moveto(x+r,y+r+hauteur/6);
    linerel(longueurarm,hauteurarm);
	line(x-r+r/2,y+r+hauteur,x-r+r/2,y+r+leg+hauteur);
	line(x+r-r/2,y+r+hauteur,x+r-r/2,y+r+leg+hauteur);
	moveto(x-r,y+r+hauteur/6);
	linerel(-longueurarm,hauteurarm);
	

}
void Dessin::deplacer_dessin(int x,int y,int r,int hauteur,int hauteurarm,int longueurarm,int leg){
	set_dessin(x,y,r,hauteur,hauteurarm,longueurarm,leg);
	
	int angle=0;

	
	while(!kbhit()){
	cleardevice();
	int a=x+250*cos(angle*3.14/180);
    int b=y+250*sin(angle*3.14/180);
	set_dessin(a,b,r,hauteur,hauteurarm,longueurarm,leg);
	
	angle+=1;
	delay(10);
	
}

}




void Dessin::deplacer_carre(int x,int y,int r,int hauteur,int hauteurarm,int longueurarm,int leg){
	set_dessin(x,y,r,hauteur,hauteurarm,longueurarm,leg);
	int k=0;
	while(!kbhit()){	
		k+=1;
	switch(k){
	case 1:
	for(int i=0;i<75;i++){
		cleardevice();
		y-=2;
	set_dessin(x,y,r,hauteur,hauteurarm,longueurarm,leg);
	delay(5);}
	break;
	case 2:
		for(int i=0;i<75;i++){
		cleardevice();
		x+=2;
	set_dessin(x,y,r,hauteur,hauteurarm,longueurarm,leg);
	delay(5);
	}
	break;
	case 3:
		for(int i=0;i<75;i++){
		cleardevice();
		y+=2;
	set_dessin(x,y,r,hauteur,hauteurarm,longueurarm,leg);
	delay(5);
	}
	break;
	case 4:
		for(int i=0;i<75;i++){
		cleardevice();
		x-=2;
	set_dessin(x,y,r,hauteur,hauteurarm,longueurarm,leg);
	delay(5);
	
	}
}
	if(k==4)
	k=0;
	
	
}

}


void Dessin::deplacer_triangle(int x,int y,int r,int hauteur,int hauteurarm,int longueurarm,int leg){	
		set_dessin(x,y,r,hauteur,hauteurarm,longueurarm,leg);
	int k=0;
	
	
	while(!kbhit()){
		
		k+=1;
	switch(k){
	case 1:
	for(int i=0;i<75;i++){
		cleardevice();
		y-=2;
		x+=2;
	set_dessin(x,y,r,hauteur,hauteurarm,longueurarm,leg);
	delay(5);
	}
	break;
	case 2:
		for(int i=0;i<75;i++){
		cleardevice();
		x+=2;
		y+=2;
	set_dessin(x,y,r,hauteur,hauteurarm,longueurarm,leg);
	delay(5);
	}
	break;
	case 3:
		for(int i=0;i<150;i++){
		cleardevice();
		x-=2;
	set_dessin(x,y,r,hauteur,hauteurarm,longueurarm,leg);
	delay(5);
	}
}
	if(k==3)
	k=0;	
}
	

}


void Dessin::transporter(int x,int y,int r,int hauteur,int hauteurarm,int longueurarm,int leg,int couleur,int dx, int dy){
	
setcolor(getbkcolor());
set_dessin(x,y,r,hauteur,hauteurarm,longueurarm,leg);
setcolor(couleur);
	this->set_dessin(x+dx,y+dy,r,hauteur,hauteurarm,longueurarm,leg);

}

